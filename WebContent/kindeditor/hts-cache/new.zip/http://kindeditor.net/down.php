<!doctype html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>下载 - KindEditor - 在线HTML编辑器</title>
		<meta name="description" content="主程序下载、插件下载、最新代码 (SVN)" />
		<link href="favicon.ico" rel="shortcut icon" type="image/x-icon" />
		<link href="./css/main.css?t=20140215.css" rel="stylesheet" />
		<link href="./prettify/prettify.css?t=20110528.css" rel="stylesheet" />
		<link href="./ke4/themes/default/default.css?t=20160331.css" rel="stylesheet" />
		<script src="./ke4/kindeditor-all-min.js?t=20160331.js"></script>
		<script src="./prettify/prettify.js?t=20110528.js"></script>
		<script>
		  var _gaq = _gaq || [];
		  _gaq.push(['_setAccount', 'UA-739852-2']);
		  _gaq.push(['_trackPageview']);
		  (function() {
			var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
			ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
			var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
		  })();
		</script>
</head>

<body>
<div id="header">
	<div id="header_top">
		<a href="index.php" id="logo" title="返回首页"><img src="images/logo.png" width="200" height="34" alt="KindEditor" /></a>
		<ul id="nav">
			<li><a href="about.php">关于</a></li>
			<li><a href="demo.php">演示</a></li>
			<li class="active"><a href="down.php">下载</a></li>
			<li><a href="doc.php">文档</a></li>
			<li><a href="case.php">成功案例</a></li>
			<li><a href="http://kindeditor.org/">English</a></li>
		</ul>
	</div>




<div id="header_bottom">
	<div id="slider_container">
		<h1 class="yahei h_fix">下载 <span>Download</span></h1>
	</div>
</div>
</div>

<div id="body">
	<div id="body_top"></div>
	<div id="body_middle" style="position:relative;">
		<ul id="breadcrumb">
			<li class="t">当前位置: </li>
			<li><a href="index.php">首页</a> &nbsp;&gt;</li>
			<li>下载</li>
		</ul>

		<div class="myblock">
			<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
			<!-- 下载页（728x90） -->
			<ins class="adsbygoogle"
			     style="display:inline-block;width:728px;height:90px"
			     data-ad-client="ca-pub-7116729301372758"
			     data-ad-slot="0602567003"></ins>
			<script>
			(adsbygoogle = window.adsbygoogle || []).push({});
			</script>
		</div>

		<div class="myblock">
			<div class="header">官方下载</div>
			<ul>
				<li style="font-size:14px;font-weight:bold;"><a href="https://github.com/kindsoft/kindeditor/releases/download/v4.1.11/kindeditor-4.1.11-zh-CN.zip">KindEditor 4.1.11 (2016-03-31)</a> [1143KB]</li>
			</ul>
		</div>

		<div class="myblock">
			<div class="header">最新源码</div>
			<ul>
				<li>Github: <a href="https://github.com/kindsoft/kindeditor" target="_blank">https://github.com/kindsoft/kindeditor</a></li>
				<li>Oschina: <a href="http://git.oschina.net/luolonghao/kindeditor" target="_blank">http://git.oschina.net/luolonghao/kindeditor</a></li>
			</ul>
		</div>

		<div class="myblock">
			<div class="header">第三方扩展</div>
			<ul>
				<li><a href="https://github.com/Macrow/rails_kindeditor" target="_blank">KindEditor for Ruby on Rails (by Macrow)</a></li>
				<li><a href="https://github.com/panxianhai/kindeditor-for-wordpress" target="_blank">KindEditor for WordPress (by panxianhai)</a></li>
				<li><a href="http://www.yiiframework.com/extension/kindeditor" target="_blank">KindEditor for Yii Framework (by Joe Chu)</a></li>
				<li><a href="http://www.yiiframework.com/extension/yii-kindeditor" target="_blank">KindEditor for Yii Framework (by jinmmd)</a></li>
			</ul>
		</div>

		<div class="myblock">
			<div class="header">变更记录</div>
			&nbsp;&nbsp;&nbsp;&nbsp;ver 4.1.11 (2016-03-31)
			<ul>
<li>新增: 俄语语言包，感谢Valery Votintsev (<a class="reference external" href="http://codersclub.org/">http://codersclub.org/</a>)。</li>
<li>改善: 语言包文件名标准化，zh_CN -&gt; zh-CN, zh_TW -&gt; zh-TW。</li>
<li>Bugfix: [IE6] 当前页面设置了document.domain，销毁编辑器会报错。</li>
<li>Bugfix: 行首全角空格被过滤。</li>
<li>Bugfix: 修复多语言包的一些小错误。</li>
<li>Bugfix: [IE11] 有些设备报错不能显示，对象不支持attachEvent属性或方法。</li>
<li>Bugfix: retina屏幕上按钮裂开。</li>
<li>Bugfix: 编辑图片后点击插入图片，弹出两个dialog。</li>
			</ul>

			&nbsp;&nbsp;&nbsp;&nbsp;<a href="docs/changelog.html" target="_blank">查看全部变更记录 ...</a>

		</div>

		<div class="clear"></div>

	</div>
	<div id="body_bottom"></div>
</div>

<style>
	#cnzz_stat_icon_253716 {
		display: inline-block;
		*display: inline;
		zoom: 1;
		vertical-align: top;
	}
</style>
<div id="footer">
	<div id="copy">
		<div>Copyright &copy; kindeditor.net &nbsp;
			<a href="http://www.miibeian.gov.cn/" target="_blank">沪ICP备13006566号-2</a> &nbsp;
			<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cdiv id='cnzz_stat_icon_253716'%3E%3C/div%3E%3Cscript src='" + cnzz_protocol + "s4.cnzz.com/stat.php%3Fid%3D253716' type='text/javascript'%3E%3C/script%3E"));</script>
		</div>
	</div>
</div>

</body>
</html>





