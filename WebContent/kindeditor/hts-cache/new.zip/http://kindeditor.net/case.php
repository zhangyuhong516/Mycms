<!doctype html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>成功案例 - KindEditor - 在线HTML编辑器</title>
		<meta name="description" content="拍拍网、站长之家、开源中国社区、中文业界咨询站、BBSMAX、ThinkPHP、emlog个人博客系统..." />
		<link href="favicon.ico" rel="shortcut icon" type="image/x-icon" />
		<link href="./css/main.css?t=20140215.css" rel="stylesheet" />
		<link href="./prettify/prettify.css?t=20110528.css" rel="stylesheet" />
		<link href="./ke4/themes/default/default.css?t=20160331.css" rel="stylesheet" />
		<script src="./ke4/kindeditor-all-min.js?t=20160331.js"></script>
		<script src="./prettify/prettify.js?t=20110528.js"></script>
		<script>
		  var _gaq = _gaq || [];
		  _gaq.push(['_setAccount', 'UA-739852-2']);
		  _gaq.push(['_trackPageview']);
		  (function() {
			var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
			ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
			var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
		  })();
		</script>
</head>

<body>
<div id="header">
	<div id="header_top">
		<a href="index.php" id="logo" title="返回首页"><img src="images/logo.png" width="200" height="34" alt="KindEditor" /></a>
		<ul id="nav">
			<li><a href="about.php">关于</a></li>
			<li><a href="demo.php">演示</a></li>
			<li><a href="down.php">下载</a></li>
			<li><a href="doc.php">文档</a></li>
			<li class="active"><a href="case.php">成功案例</a></li>
			<li><a href="http://kindeditor.org/">English</a></li>
		</ul>
	</div>




<div id="header_bottom">
	<div id="slider_container">
		<h1 class="yahei h_fix">成功案例 <span>Who is using</span></h1>
	</div>
</div>
</div>

<div id="body">
	<div id="body_top"></div>
	<div id="body_middle">
		<ul id="breadcrumb">
			<li class="t">当前位置: </li>
			<li><a href="index.php">首页</a> &nbsp;&gt;</li>
			<li>成功案例</li>
		</ul>

		<div class="myblock">
			<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
			<!-- 成功案例页（728x90） -->
			<ins class="adsbygoogle"
			     style="display:inline-block;width:728px;height:90px"
			     data-ad-client="ca-pub-7116729301372758"
			     data-ad-slot="3758295930"></ins>
			<script>
			(adsbygoogle = window.adsbygoogle || []).push({});
			</script>
		</div>

		<div class="myblock">
			<div class="header">运营网站</div>
			<div class="case-item">
				<a href="http://www.paipai.com/" target="_blank">
					<img src="images/logo/paipai.gif" height="50" alt="拍拍网" title="拍拍网" />
				</a>
			</div>
			<div class="case-item">
				<a href="http://www.youdao.com/" target="_blank">
					<img src="images/logo/youdao.gif" height="50" alt="有道" title="有道" />
				</a>
			</div>
			<div class="case-item">
				<a href="http://www.tudou.com/" target="_blank">
					<img src="images/logo/tudou.gif" height="50" alt="土豆网" title="土豆网" />
				</a>
			</div>
			<div class="case-item">
				<a href="http://www.snda.com/" target="_blank">
					<img src="images/logo/snda.gif" height="50" alt="盛大网络" title="盛大网络" />
				</a>
			</div>
			<div class="case-item">
				<a href="http://www.huawei.com/" target="_blank">
					<img src="images/logo/huawei.gif" height="50" alt="华为" title="华为" />
				</a>
			</div>
			<div class="case-item">
				<a href="http://www.chinaz.com/" target="_blank">
					<img src="images/logo/chinaz.gif" height="50" alt="站长之家" title="站长之家" />
				</a>
			</div>
			<div class="case-item">
				<a href="http://www.oschina.net/" target="_blank">
					<img src="images/logo/oschina.gif" height="50" alt="开源中国社区" title="开源中国社区" />
				</a>
			</div>
			<div class="case-item">
				<a href="http://www.cnbeta.com/" target="_blank">
					<img src="images/logo/cnbeta.gif" height="50" alt="中文业界咨询站" title="中文业界咨询站" />
				</a>
			</div>
			<div class="case-item">
				<a href="http://www.pcpop.com/" target="_blank">
					<img src="images/logo/pcpop.gif" height="50" alt="泡泡网" title="泡泡网" />
				</a>
			</div>
			<div class="case-item">
				<a href="http://www.ddmap.com/" target="_blank">
					<img src="images/logo/ddmap.gif" height="50" alt="丁丁地图" title="丁丁地图" />
				</a>
			</div>
			<div class="case-item">
				<a href="http://www.cyworld.com.cn/" target="_blank">
					<img src="images/logo/cyworld.gif" height="50" alt="赛我中国" title="赛我中国" />
				</a>
			</div>
			<div class="case-item">
				<a href="http://www.gxtv.cn/" target="_blank">
					<img src="images/logo/gxtv.gif" height="50" alt="广西电视网" title="广西电视网" />
				</a>
			</div>
			<div class="case-item">
				<a href="http://www.mocook.com/" target="_blank">
					<img src="images/logo/mocook.gif" height="50" alt="妙客美食网" title="妙客美食网" />
				</a>
			</div>
			<div class="case-item">
				<a href="http://www.axtrip.com/" target="_blank">
					<img src="images/logo/axtrip.gif" height="50" alt="深圳旅游集散中心" title="深圳旅游集散中心" />
				</a>
			</div>
			<div class="case-item">
				<a href="http://www.ideal.sh.cn/" target="_blank">
					<img src="images/logo/ideal.gif" height="50" alt="中国电信上海理想信息产业（集团）有限公司" title="中国电信上海理想信息产业（集团）有限公司" />
				</a>
			</div>
			<div class="case-item">
				<a href="http://www.pazhou.net/" target="_blank">
					<img src="images/logo/pazhou.gif" height="50" alt="琶洲网" title="琶洲网" />
				</a>
			</div>
			<div class="case-item">
				<a href="http://www.iplayshopping.com/" target="_blank">
					<img src="images/logo/iplayshopping.gif" height="50" alt="第三评" title="第三评 - 以消费者的视角做有专业态度的第三方观察与评测媒体" />
				</a>
			</div>
		</div>
		<div class="myblock">
			<div class="header">网络软件</div>
			<div class="case-item">
				<a href="http://ccflow.org/" target="_blank">
					<img src="images/logo/ccflow.gif" height="50" alt="开源的驰骋asp.net工作流引擎" title="开源的驰骋asp.net工作流引擎" />
				</a>
			</div>
			<div class="case-item">
				<a href="http://www.xtools.cn/" target="_blank">
					<img src="images/logo/xtools.gif" height="50" alt="在线·月租型·客户关系管理软件/CRM软件/销售管理软件" title="在线·月租型·客户关系管理软件/CRM软件/销售管理软件" />
				</a>
			</div>
			<div class="case-item">
				<a href="http://www.shopxx.net/" target="_blank">
					<img src="images/logo/shopxx.gif" height="50" alt="SHOP++网店系统" title="SHOP++网店系统" />
				</a>
			</div>
			<div class="case-item">
				<a href="http://www.emlog.net/" target="_blank">
					<img src="images/logo/emlog.gif" height="50" alt="emlog个人博客系统" title="emlog个人博客系统" />
				</a>
			</div>
			<div class="case-item">
				<a href="http://www.zentao.net/" target="_blank">
					<img src="images/logo/zentao.gif" height="50" alt="开源项目管理软件" title="开源项目管理软件" />
				</a>
			</div>
			<div class="case-item">
				<a href="http://www.modoer.com/" target="_blank">
					<img src="images/logo/modoer.gif" height="50" alt="Modoer" title="Modoer" />
				</a>
			</div>
			<div class="case-item">
				<a href="http://www.74cms.com/" target="_blank">
					<img src="images/logo/74cms.gif" height="50" alt="骑士CMS" title="骑士CMS" />
				</a>
			</div>
			<div class="case-item">
				<a href="http://www.yidacms.com/" target="_blank">
					<img src="images/logo/yidacms.jpg" height="50" alt="企业建站系统" title="企业建站系统" />
				</a>
			</div>
			<div class="case-item">
				<a href="http://www.phpyun.com/" target="_blank">
					<img src="images/logo/phpyun.png" height="50" alt="PHPYun人才系统" title="PHPYun人才系统" />
				</a>
			</div>
		</div>
		<div class="clear"></div>
	</div>
	<div id="body_bottom"></div>
</div>

<style>
	#cnzz_stat_icon_253716 {
		display: inline-block;
		*display: inline;
		zoom: 1;
		vertical-align: top;
	}
</style>
<div id="footer">
	<div id="copy">
		<div>Copyright &copy; kindeditor.net &nbsp;
			<a href="http://www.miibeian.gov.cn/" target="_blank">沪ICP备13006566号-2</a> &nbsp;
			<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cdiv id='cnzz_stat_icon_253716'%3E%3C/div%3E%3Cscript src='" + cnzz_protocol + "s4.cnzz.com/stat.php%3Fid%3D253716' type='text/javascript'%3E%3C/script%3E"));</script>
		</div>
	</div>
</div>

</body>
</html>





