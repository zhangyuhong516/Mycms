<!doctype html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>文档 - KindEditor - 在线HTML编辑器</title>
		<meta name="description" content="编辑器使用方法, 编辑器初始化参数, 更改编辑器外观, 添加自定义插件" />
		<link href="favicon.ico" rel="shortcut icon" type="image/x-icon" />
		<link href="./css/main.css?t=20140215.css" rel="stylesheet" />
		<link href="./prettify/prettify.css?t=20110528.css" rel="stylesheet" />
		<link href="./ke4/themes/default/default.css?t=20160331.css" rel="stylesheet" />
		<script src="./ke4/kindeditor-all-min.js?t=20160331.js"></script>
		<script src="./prettify/prettify.js?t=20110528.js"></script>
		<script>
		  var _gaq = _gaq || [];
		  _gaq.push(['_setAccount', 'UA-739852-2']);
		  _gaq.push(['_trackPageview']);
		  (function() {
			var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
			ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
			var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
		  })();
		</script>
</head>

<body>
<div id="header">
	<div id="header_top">
		<a href="index.php" id="logo" title="返回首页"><img src="images/logo.png" width="200" height="34" alt="KindEditor" /></a>
		<ul id="nav">
			<li><a href="about.php">关于</a></li>
			<li><a href="demo.php">演示</a></li>
			<li><a href="down.php">下载</a></li>
			<li class="active"><a href="doc.php">文档</a></li>
			<li><a href="case.php">成功案例</a></li>
			<li><a href="http://kindeditor.org/">English</a></li>
		</ul>
	</div>




<div id="header_bottom">
	<div id="slider_container">
		<h1 class="yahei h_fix">文档 <span>Documentation</span></h1>
	</div>
</div>
</div>

<div id="body">
	<div id="body_top"></div>
	<div id="body_middle" style="position:relative;">
		<ul id="breadcrumb">
			<li class="t">当前位置: </li>
			<li><a href="index.php">首页</a> &nbsp;&gt;</li>
			<li>文档</li>
		</ul>

		<div class="myblock">
			<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
			<!-- 文档页（728x90） -->
			<ins class="adsbygoogle"
			     style="display:inline-block;width:728px;height:90px"
			     data-ad-client="ca-pub-7116729301372758"
			     data-ad-slot="6563401767"></ins>
			<script>
			(adsbygoogle = window.adsbygoogle || []).push({});
			</script>
		</div>

		<div class="myblock">
			<div class="header">KindEditor 4.x 文档</div>
			<ul>
				<li><a href="docs/usage.html" target="_blank">编辑器使用方法</a></li>
				<li><a href="docs/upgrade.html" target="_blank">从3.x升级到4.x版本</a></li>
				<li><a href="docs/option.html" target="_blank">编辑器初始化参数</a></li>
				<li><a href="docs/theme.html" target="_blank">更改编辑器外观</a></li>
				<li><a href="docs/plugin.html" target="_blank">添加自定义插件</a></li>
				<li><a href="docs/upload.html" target="_blank">上传文件</a></li>
				<li><a href="docs/qna.html" target="_blank">常见问题</a></li>
				<li><a href="docs/core.html" target="_blank">基础(Base) API</a></li>
				<li><a href="docs/event.html" target="_blank">事件(Event) API</a></li>
				<li><a href="docs/selector.html" target="_blank">选择器(Selector) API</a></li>
				<li><a href="docs/node.html" target="_blank">Node API</a></li>
				<li><a href="docs/range.html" target="_blank">Range API</a></li>
				<li><a href="docs/cmd.html" target="_blank">Command API</a></li>
				<li><a href="docs/ajax.html" target="_blank">Ajax API</a></li>
				<li><a href="docs/widget.html" target="_blank">Widget API</a></li>
				<li><a href="docs/menu.html" target="_blank">下拉菜单(Menu) API</a></li>
				<li><a href="docs/colorpicker.html" target="_blank">取色器(ColorPicker) API</a></li>
				<li><a href="docs/dialog.html" target="_blank">弹出窗口(Dialog) API</a></li>
				<li><a href="docs/tabs.html" target="_blank">Tabs API</a></li>
				<li><a href="docs/uploadbutton.html" target="_blank">上传按钮(UplaodButton) API</a></li>
				<li><a href="docs/editor.html" target="_blank">编辑器(Editor) API</a></li>
			</ul>
		</div>

		<div class="myblock">
			<div class="header">KindEditor 3.x 文档</div>
			<ul>
				<li><a href="doc3.php" target="_blank">编辑器调用方法</a></li>
				<li><a href="doc3.php?cmd=config" target="_blank">编辑器初始化参数</a></li>
				<li><a href="doc3.php?cmd=plugin" target="_blank">添加自定义插件</a></li>
				<li><a href="doc3.php?cmd=api" target="_blank">API文档</a></li>
				<li><a href="doc3.php?cmd=qna" target="_blank">常见问题</a></li>
			</ul>
		</div>

		<div class="clear"></div>

	</div>
	<div id="body_bottom"></div>
</div>

<style>
	#cnzz_stat_icon_253716 {
		display: inline-block;
		*display: inline;
		zoom: 1;
		vertical-align: top;
	}
</style>
<div id="footer">
	<div id="copy">
		<div>Copyright &copy; kindeditor.net &nbsp;
			<a href="http://www.miibeian.gov.cn/" target="_blank">沪ICP备13006566号-2</a> &nbsp;
			<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cdiv id='cnzz_stat_icon_253716'%3E%3C/div%3E%3Cscript src='" + cnzz_protocol + "s4.cnzz.com/stat.php%3Fid%3D253716' type='text/javascript'%3E%3C/script%3E"));</script>
		</div>
	</div>
</div>

</body>
</html>





