<!doctype html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>关于 - KindEditor - 在线HTML编辑器</title>
		<meta name="description" content="KindEditor 是一套开源的在线HTML编辑器，主要用于让用户在网站上获得所见即所得编辑效果，开发人员可以用 KindEditor 把传统的多行文本输入框(textarea)替换为可视化的富文本输入框。KindEditor 使用 JavaScript 编写，可以无缝地与 Java、.NET、PHP、ASP 等程序集成，比较适合在 CMS、商城、论坛、博客、Wiki、电子邮件等互联网应用上使用，" />
		<link href="favicon.ico" rel="shortcut icon" type="image/x-icon" />
		<link href="./css/main.css?t=20140215.css" rel="stylesheet" />
		<link href="./prettify/prettify.css?t=20110528.css" rel="stylesheet" />
		<link href="./ke4/themes/default/default.css?t=20160331.css" rel="stylesheet" />
		<script src="./ke4/kindeditor-all-min.js?t=20160331.js"></script>
		<script src="./prettify/prettify.js?t=20110528.js"></script>
		<script>
		  var _gaq = _gaq || [];
		  _gaq.push(['_setAccount', 'UA-739852-2']);
		  _gaq.push(['_trackPageview']);
		  (function() {
			var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
			ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
			var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
		  })();
		</script>
</head>

<body>
<div id="header">
	<div id="header_top">
		<a href="index.php" id="logo" title="返回首页"><img src="images/logo.png" width="200" height="34" alt="KindEditor" /></a>
		<ul id="nav">
			<li class="active"><a href="about.php">关于</a></li>
			<li><a href="demo.php">演示</a></li>
			<li><a href="down.php">下载</a></li>
			<li><a href="doc.php">文档</a></li>
			<li><a href="case.php">成功案例</a></li>
			<li><a href="http://kindeditor.org/">English</a></li>
		</ul>
	</div>




<div id="header_bottom">
	<div id="slider_container">
		<h1 class="yahei h_fix">关于 <span>About</span></h1>
	</div>
</div>
</div>

<div id="body">
	<div id="body_top"></div>
	<div id="body_middle">
		<ul id="breadcrumb">
			<li class="t">当前位置: </li>
			<li><a href="index.php">首页</a> &nbsp;&gt;</li>
			<li>关于</li>
		</ul>

		<div class="about_me">
			<h1 class="yahei h_fix"><a href="http://index.baidu.com/main/word.php?word=kindeditor" target="_blank">KindEditor</a> 是什么？</h1>
			KindEditor 是一套开源的在线HTML编辑器，主要用于让用户在网站上获得所见即所得编辑效果，开发人员可以用 KindEditor 把传统的多行文本输入框(textarea)替换为可视化的富文本输入框。
			KindEditor 使用 JavaScript 编写，可以无缝地与 Java、.NET、PHP、ASP 等程序集成，比较适合在 CMS、商城、论坛、博客、Wiki、电子邮件等互联网应用上使用。
		</div>

		<div class="myblock">
			<div class="header">主要特点</div>
			<ul>
				<li>快速：体积小，加载速度快</li>
				<li>开源：开放源代码，高水平，高品质</li>
				<li>底层：内置自定义 DOM 类库，精确操作 DOM</li>
				<li>扩展：基于插件的设计，所有功能都是插件，可根据需求增减功能</li>
				<li>风格：修改编辑器风格非常容易，只需修改一个 CSS 文件</li>
				<li>兼容：支持大部分主流浏览器，比如 IE、Firefox、Safari、Chrome、Opera</li>
			</ul>
		</div>

		<div class="myblock">
			<div class="header">发展历程</div>
			<ul>
				<li>2006年07月：KindEditor 2.0 发布</li>
				<li>2009年01月：KindEditor 3.0 发布</li>
				<li>2010年06月：KindEditor 3.5 发布</li>
				<li>2011年08月：KindEditor 4.0 发布</li>
			</ul>
		</div>

		<div class="clear"></div>

	</div>
	<div id="body_bottom"></div>
</div>

<style>
	#cnzz_stat_icon_253716 {
		display: inline-block;
		*display: inline;
		zoom: 1;
		vertical-align: top;
	}
</style>
<div id="footer">
	<div id="copy">
		<div>Copyright &copy; kindeditor.net &nbsp;
			<a href="http://www.miibeian.gov.cn/" target="_blank">沪ICP备13006566号-2</a> &nbsp;
			<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cdiv id='cnzz_stat_icon_253716'%3E%3C/div%3E%3Cscript src='" + cnzz_protocol + "s4.cnzz.com/stat.php%3Fid%3D253716' type='text/javascript'%3E%3C/script%3E"));</script>
		</div>
	</div>
</div>

</body>
</html>





