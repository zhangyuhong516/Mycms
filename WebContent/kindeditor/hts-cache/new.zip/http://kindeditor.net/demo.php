<!doctype html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>在线HTML编辑器</title>
		<meta name="description" content="默认模式、简单模式、手动加载编辑器、默认模式为代码模式、手动添加CSS文件、只能调整高度, 禁止调整大小..." />
		<link href="favicon.ico" rel="shortcut icon" type="image/x-icon" />
		<link href="./css/main.css?t=20140215.css" rel="stylesheet" />
		<link href="./prettify/prettify.css?t=20110528.css" rel="stylesheet" />
		<link href="./ke4/themes/default/default.css?t=20160331.css" rel="stylesheet" />
		<script src="./ke4/kindeditor-all-min.js?t=20160331.js"></script>
		<script src="./prettify/prettify.js?t=20110528.js"></script>
		<script>
		  var _gaq = _gaq || [];
		  _gaq.push(['_setAccount', 'UA-739852-2']);
		  _gaq.push(['_trackPageview']);
		  (function() {
			var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
			ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
			var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
		  })();
		</script>
</head>

<body>
<div id="header">
	<div id="header_top">
		<a href="index.php" id="logo" title="返回首页"><img src="images/logo.png" width="200" height="34" alt="KindEditor" /></a>
		<ul id="nav">
			<li><a href="about.php">关于</a></li>
			<li class="active"><a href="demo.php">演示</a></li>
			<li><a href="down.php">下载</a></li>
			<li><a href="doc.php">文档</a></li>
			<li><a href="case.php">成功案例</a></li>
			<li><a href="http://kindeditor.org/">English</a></li>
		</ul>
	</div>




<script>
KindEditor.ready(function(K) {
	K.create('#ke_demo', {
		allowFileManager : true
	});
});
</script>

<div id="header_bottom">
	<div id="slider_container">
		<h1 class="yahei h_fix">演示 <span>Demo</span></h1>
	</div>
</div>
</div>

<div id="body">
	<div id="body_top"></div>
	<div id="body_middle">
		<ul id="breadcrumb">
			<li class="t">当前位置: </li>
			<li><a href="index.php">首页</a> &nbsp;&gt;</li>
			<li>演示</li>
		</ul>

		<div class="myblock">
			<script type="text/javascript"><!--
			google_ad_client = "ca-pub-7116729301372758";
			/* 演示页 */
			google_ad_slot = "8255125061";
			google_ad_width = 728;
			google_ad_height = 90;
			//-->
			</script>
			<script type="text/javascript"
			src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
			</script>
		</div>

		<div class="myblock">
			<textarea id="ke_demo" name="content" rows="20" cols="100" style="width:95%;height:200px;visibility:hidden;">
&lt;p&gt;Think Defferent&lt;/p&gt;
&lt;p&gt;Here’s to the crazy ones. The misfits. The rebels. The troublemakers. The round pegs in the square holes. The ones who see things differently. They’re not fond of rules. And they have no respect for the status quo. You can quote them, disagree with them, glorify or vilify them. About the only thing you can’t do is ignore them. Because they change things. They push the human race forward. And while some may see them as the crazy ones, we see genius. Because the people who are crazy enough to think they can change the world, are the ones who do.&nbsp;&lt;/p&gt;
&lt;p&gt;- Apple Inc.&lt;/p&gt;
			</textarea>
		</div>

		<div class="myblock">
			<div class="header">编辑器演示</div>
			<ul>
				<li><a href="ke4/examples/default.html" target="_blank">default.html</a> (默认模式)</li>
				<li><a href="ke4/examples/simple.html" target="_blank">simple.html</a> (简单模式)</li>
				<li><a href="ke4/examples/dynamic-load.html" target="_blank">dynamic-load.html</a> (异步加载)</li>
				<li><a href="ke4/examples/multi-language.html" target="_blank">multi-language.html</a> (多语言)</li>
				<li><a href="ke4/examples/readonly.html" target="_blank">readonly.html</a> (只读模式)</li>
				<li><a href="ke4/examples/newline.html" target="_blank">newline.html</a> (回车换行设置)</li>
				<li><a href="ke4/examples/word-count.html" target="_blank">word-count.html</a> (统计字数)</li>
				<li><a href="ke4/examples/filter-mode.html" target="_blank">filter-mode.html</a> (关闭HTML过滤)</li>
				<li><a href="ke4/examples/url-type.html" target="_blank">url-type.html</a> (URL设置)</li>
				<li><a href="ke4/examples/paste-type.html" target="_blank">paste-type.html</a> (粘贴设置)</li>
				<li><a href="ke4/examples/auto-height.html" target="_blank">auto-height.html</a> (自动调整高度)</li>
				<li><a href="ke4/examples/custom-theme.html" target="_blank">custom-theme.html</a> (自定义风格)</li>
				<li><a href="ke4/examples/qqstyle.html" target="_blank">qqstyle.html</a> (自定义风格 仿QQ邮箱)</li>
				<li><a href="ke4/examples/custom-plugin.html" target="_blank">custom-plugin.html</a> (自定义插件)</li>
			</ul>
		</div>
		<div class="myblock">
			<div class="header">使用其它类库</div>
			<ul>
				<li><a href="ke4/examples/jquery.html" target="_blank">jquery.html</a> (jQuery)</li>
				<li><a href="ke4/examples/mootools.html" target="_blank">mootools.html</a> (MooTools)</li>
				<li><a href="ke4/examples/jquery-ui.html" target="_blank">jquery-ui.html</a> (jQuery UI)</li>
			</ul>
		</div>
		<div class="myblock">
			<div class="header">单独调用组件</div>
			<ul>
				<li><a href="ke4/examples/node.html" target="_blank">node.html</a> (Node操作)</li>
				<li><a href="ke4/examples/uploadbutton.html" target="_blank">uploadbutton.html</a> (上传按钮)</li>
				<li><a href="ke4/examples/dialog.html" target="_blank">dialog.html</a> (弹出框)</li>
				<li><a href="ke4/examples/colorpicker.html" target="_blank">colorpicker.html</a> (取色器)</li>
				<li><a href="ke4/examples/file-manager.html" target="_blank">file-manager.html</a> (浏览服务器)</li>
				<li><a href="ke4/examples/image-dialog.html" target="_blank">image-dialog.html</a> (上传图片弹出框)</li>
				<li><a href="ke4/examples/multi-image-dialog.html" target="_blank">multi-image-dialog.html</a> (批量上传弹出框)</li>
				<li><a href="ke4/examples/file-dialog.html" target="_blank">file-dialog.html</a> (上传文件弹出框)</li>
			</ul>
		</div>
		<div class="myblock" style="text-indent:2em;">
			注：因服务器空间原因，在本站演示里上传后都不保存文件，返回固定的URL。
		</div>

		<div class="home-link" style="padding: 30px 20px 10px 20px;margin-top:30px;">
			友情链接:
			<ul>
				<li><a href="http://www.miniui.com/" target="_blank">jQuery MiniUI</a></li>
				<li><a href="http://www.thinkphp.cn/" target="_blank">ThinkPHP</a></li>
				<li><a href="http://simpleframework.net/" target="_blank">SimpleFramework</a></li>
				<li><a href="http://www.xheditor.com/" target="_blank">xhEditor</a></li>
				<li><a href="http://www.zentao.net/" target="_blank">禅道</a></li>
				<li><a href="http://www.ralasafe.cn/" target="_blank">Ralasafe权限管理</a></li>
				<li><a href="http://www.aspcms.com/" target="_blank">aspcms</a></li>
				<li><a href="http://www.veryide.com/" target="_blank">VeryIDE</a></li>
				<li><a href="http://www.guqiu.com/" target="_blank">精品课程</a></li>
				<li><a href="http://www.xiake.net/" target="_blank">侠客站群</a></li>
				<li><a href="http://www.cnwtn.com/" target="_blank">企能SEO平台</a></li>
				<li><a href="http://www.szbgw.cn/" target="_blank">彩票软件</a></li>
				<li><a href="http://ccflow.org/" target="_blank">工作流引擎</a></li>
				<li><a href="http://fineui.com/" target="_blank">FineUI</a></li>
				<li><a href="http://www.phpyun.com/" target="_blank">PHPYun人才系统</a></li>
				<li><a href="http://haoshenqi.com/" target="_blank">二手笔记本商城</a></li>
				<li><a href="http://www.kfzds.com/" target="_blank">振动筛</a></li>
				<li><a href="http://www.fangshuigongcheng.net/" target="_blank">防水工程</a></li>
			</ul>
			<div class="clear"></div>
		</div>

	</div>
	<div id="body_bottom"></div>
</div>


<style>
	#cnzz_stat_icon_253716 {
		display: inline-block;
		*display: inline;
		zoom: 1;
		vertical-align: top;
	}
</style>
<div id="footer">
	<div id="copy">
		<div>Copyright &copy; kindeditor.net &nbsp;
			<a href="http://www.miibeian.gov.cn/" target="_blank">沪ICP备13006566号-2</a> &nbsp;
			<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cdiv id='cnzz_stat_icon_253716'%3E%3C/div%3E%3Cscript src='" + cnzz_protocol + "s4.cnzz.com/stat.php%3Fid%3D253716' type='text/javascript'%3E%3C/script%3E"));</script>
		</div>
	</div>
</div>

</body>
</html>





